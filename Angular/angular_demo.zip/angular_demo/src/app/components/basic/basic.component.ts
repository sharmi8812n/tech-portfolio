import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-basic',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './basic.component.html',
  styleUrl: './basic.component.css'
})
export class BasicComponent {

  firstname: string = "Angular";
  angularVersion= "18";
  version: number=18;
  isActive: boolean = true;
  currentDate: Date= new Date();
  inputType1: string = "radio";
  inputType2: string = "checkbox";
  inputType3: string = "button";
  selectedVersion: string ='';


  showWelcomeAlert(){
    alert("Welcome to angular 18!!!")
  }

  showMessage(messageStr :string){
    alert(messageStr)
  }

  showFailedAlert(){
    alert("Action Failed")
  }
}
